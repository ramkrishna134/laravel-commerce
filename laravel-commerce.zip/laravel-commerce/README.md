<p align="center"><h1>Test Commerce</h1></p>



## About Test Commerce

Test Commerce is a e-Commerce platform build in Laravel Freamwork.

## Installation

Please check the official laravel installation guide for server requirements before you start. [Official Documentation](https://laravel.com/docs/9.x)

Clone the repository

    git clone https://github.com/ramkrishna134/test-commerce.git

Switch to the repo folder

    cd laravel-commerce

Generate a new application key

    php artisan key:generate

Start the local development server

    php artisan serve

You can now access the server at http://localhost:8000

**TL;DR command list**

    git clone https://github.com/ramkrishna134/test-commerce.git
    cd test-commerce
    composer install
    cp .env.example .env
    php artisan key:generate

**If Composer install return error**
    composer update
    composer install

**Make sure you set the correct database connection information before running the migrations** [Environment variables](#environment-variables)

    php artisan migrate
    php artisan serve

## Database seeding

**Populate the database with seed data with relationships which includes users, products, categories,. This can help you to quickly start testing frontend and start using it with ready content.**

Open the DatabaseSeeder and set the property values as per your requirement

    database/seeders/DatabaseSeeder.php

Run the database seeder and you're done

    php artisan db:seed




