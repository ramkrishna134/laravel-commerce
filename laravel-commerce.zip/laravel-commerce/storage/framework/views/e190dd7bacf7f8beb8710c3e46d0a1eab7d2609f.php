<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> Test Commerce</title>
    <!-- Meta Tags -->
    <meta name="title" content="<?php echo $__env->yieldContent('title'); ?> Test Commerce">
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('keyword'); ?>">
    <meta property="og:image"  content="<?php echo $__env->yieldContent('image'); ?>">
    <meta name="author" content="Test Commerce">

    <meta name="twitter:card" value="<?php echo $__env->yieldContent('description'); ?>">

    <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>" />
    <meta property="og:type" content="<?php echo $__env->yieldContent('description'); ?>" />
    <meta property="og:image" content="<?php echo $__env->yieldContent('image'); ?>" />
    <meta property="og:image:alt" content="<?php echo $__env->yieldContent('title'); ?>" />
    <meta property="og:description" content="<?php echo $__env->yieldContent('description'); ?>" />

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"/>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm p-0 sticky-top">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    Test Commerce
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                        <form class="search-box">
                            
                            <div class="search-element">
                                <input type="text" placeholder="Type to Search ..." id="txtSearch" id="txtSearch" class="form-control" aria-label="Search accross the website">
                                <i class="fa-solid fa-magnifying-glass"></i>
                            </div>

                            <?php echo e(csrf_field()); ?>

                            <div id="search-result" class="result shadow"></div>
                        </form>

                    </ul>


                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto align-items-center">

                        <li class="nav-item">
                            <a href="/" class="nav-link">Products</a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('category.list')); ?>" class="nav-link">Categories</a>
                        </li>


                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>

                        <?php
                        $user = auth()->user();
                        $roles = $user->getRoleNames();
                        ?>

                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <img width="30" src="<?php echo e(Avatar::create(Auth::user()->name)->toBase64()); ?>" /> <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">

                                    <?php if(!$roles->isEmpty()): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">Admin Dashboard</a>
                                    <hr>
                                    <?php endif; ?>

                                    <a class="dropdown-item" href="<?php echo e(route('order.index')); ?>">Your Orders</a>

                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>

                        <a href="<?php echo e(route('cart.list')); ?>" class="cart-button position-relative">
                            <i class="fa-solid fa-bag-shopping"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?php echo e(Cart::getTotalQuantity()); ?>

                              <span class="visually-hidden">Items</span>
                            </span>
                        </a>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="pb-4 mb-5">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <footer class="footer py-4 bg-white shadow">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-sm-4">
                        <a class="" href="<?php echo e(url('/')); ?>">
                            <img class="img-fluid" width="150px" src="/storage/assets/logo.png" alt="">
                        </a>
                    </div>
    
                    <div class="col-sm-4">
                        <ul>
                            <li><a href="">About</a></li>
                            <li><a href="">Contact Us</a></li>
                            <li><a href="">Privacy Policy</a></li>
                        </ul>
                    </div>

                    <div class="col-sm-4">
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Cum, eos asperiores quae facere dolor consequatur maiores quos corrupti? Animi exercitationem, tenetur alias omnis cupiditate consectetur suscipit odio debitis qui doloribus.</p>
                    </div>
                </div>
            </div>
        </footer>

        <div class="foot-line py-2 bg-dark text-center">
            <div class="container">
                <p class="mb-0 text-light">© <?php echo e(date('Y')); ?>, Test Commerce. All Rights Reserved.</p>
            </div>
        </div>
    </div>




    <script type="text/javascript">
  
      $(document).ready(function (){
  
        searchbox();
  
      })
      
      function searchbox() {
  
      let searchKeyTimer = null;
      let searchAjax = null;
      let $searchBox = $('.search-box');
      let $searchInput = $searchBox.find('#txtSearch');
      let $searchResults = $searchBox.find('#search-result');
  
  
      $searchBox.click(function(e){
          e.stopPropagation();
      });
  
      $searchInput.keyup(function( e ){
  
          if( e.which === 27 ){
  
              $searchResults.hide();
  
              if( searchKeyTimer ){
                  clearTimeout( searchKeyTimer );
                  searchKeyTimer = null;
              }
              if( searchAjax ){
                  searchAjax.abort();
                  searchAjax = null;
              }
  
              return;
          }
  
          if( searchKeyTimer ){
              clearTimeout( searchKeyTimer );
              searchKeyTimer = null;
          }
  
          searchKeyTimer = setTimeout( search, 250 );
  
      });
  
      function search() {
  
          if( searchAjax ){
              searchAjax.abort();
              searchAjax = null;
          }
  
          $searchResults.hide();
          $searchResults.html("");
          $('#txtSearch').removeClass('active');
  
          let query = $.trim( $searchInput.val() );
          if( query.length === 0 ) return;
  
  
        if(query != ''){
          var _token = $('input[name="_token"]').val();
  
          $.ajax({
  
          method:"POST",
          url: "<?php echo e(route('search')); ?>",
          data: {
            query : query,
            _token : _token
          },
          success: function(data) {
              response = data;
              $('#search-result').fadeIn();
              $('#txtSearch').addClass('active');
              
  
              data.forEach(function(item) {
                item.forEach(function(single){
                  const descrip = single['description'].substring(0, 200)
                  console.log(descrip);
                  var html = ('<a href="/product/'+single['slug']+'">'+'<strong>'+single['title']+'</strong>');
                  
                  $('#search-result').append(html);
  
                })
                
              });
  
              const numb = document.getElementById("search-result").children.length;
              if(numb == 0){
                var html = ('<strong>No result found ...</strong>');
                $('#search-result').append(html);
              }
              
  
              
              
          }
  
  
  
          });
  
        }
      }
  
      $('body').click(function(){
          $searchResults.hide();
          $searchResults.html("");
          $('#txtSearch').removeClass('active');
      });
  
      }
  
  
        
      </script>



</body>
</html>
<?php /**PATH /home/cietncert/test-commerce/resources/views/layouts/app.blade.php ENDPATH**/ ?>