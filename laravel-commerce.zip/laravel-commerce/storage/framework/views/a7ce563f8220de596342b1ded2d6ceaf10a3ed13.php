<?php ( 
$user = \auth()->user() ?? NULL
); ?>



<?php $__env->startSection('title'); ?> Checkout | <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('success')): ?>
    <div class="position-fixed bottom-0 end-0 p-3">
        <div class="toast fade show align-items-center text-white bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
            <div class="toast-body">
                <i class="fa-solid fa-check"></i> <?php echo e($message); ?>

            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="breadcrumb-wrap bg-info py-2 mt-1">
    <div class="container">
        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
              <li class="breadcrumb-item"><a href="/">Home</a></li>
              <li class="breadcrumb-item"><a href="<?php echo e(route('cart.list')); ?>">Cart</a></li>
              <li class="breadcrumb-item active" aria-current="page">CheckOut</li>
            </ol>
          </nav>
    </div>
</div>

<div class="container mt-4">

    <h1 class="h2 text-center">Checkout</h1>
    
    <form action="<?php echo e(route('order.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row justify-content-center">

            <?php if(count($cartItems) != 0): ?>
    
            <div class="col-sm-8">
                
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="mb-3">
                                    <label for="billing_name" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="billing_name" name="billing_name" class="form-control" required placeholder="Full Name" value="<?php echo e($user->name ?? ''); ?>">
                                    <?php $__errorArgs = ['billing_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="col-sm-6">
                                <div class="mb-3">
                                    <label for="billing_email" class="form-label">Email ID</label>
                                    <input type="email" class="form-control" id="billing_email" name="billing_email" class="form-control" required placeholder="Email ID" value="<?php echo e($user->email ?? ''); ?>">
                                    <?php $__errorArgs = ['billing_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="col-sm-6">
                                <label for="billing_company" class="form-label">Company <small>(Optional)</small></label>
                                <input type="text" class="form-control" id="billing_company" name="billing_company" class="form-control" placeholder="Company" value="<?php echo e(old('billing_company')); ?>">
                                <?php $__errorArgs = ['billing_company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
    
                            <div class="col-sm-6">
                                <div class="mb-3">
                                    <label for="billing_phone" class="form-label">Phone No.</label>
                                    <input type="tel" class="form-control" id="billing_phone" name="billing_phone" class="form-control" required placeholder="Phone No." value="<?php echo e(old('billing_phone')); ?>">
                                    <?php $__errorArgs = ['billing_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="col-sm-6">
                                <div class="mb-3">
                                    <label for="billing_country" class="form-label">Country</label>
                                    <input type="text" class="form-control" id="billing_country" name="billing_country" class="form-control" required placeholder="Country" value="<?php echo e(old('billing_country')); ?>">
                                    <?php $__errorArgs = ['billing_country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="col-sm-6">
                                <div class="mb-3">
                                    <label for="billing_city" class="form-label">City</label>
                                    <input type="text" class="form-control" id="billing_city" name="billing_city" class="form-control" required placeholder="City" value="<?php echo e(old('billing_city')); ?>">
                                    <?php $__errorArgs = ['billing_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="col-sm-6">
                                <div class="mb-3">
                                    <label for="billing_state" class="form-label">State</label>
                                    <input type="text" class="form-control" id="billing_state" name="billing_state" class="form-control" required placeholder="State" value="<?php echo e(old('billing_state')); ?>">
                                    <?php $__errorArgs = ['billing_state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="col-sm-6">
                                <div class="mb-3">
                                    <label for="billing_pincode" class="form-label">Pin Code</label>
                                    <input type="text" class="form-control" id="billing_pincode" name="billing_pincode" class="form-control" required placeholder="ZIP / Pin Code" value="<?php echo e(old('billing_pincode')); ?>">
                                    <?php $__errorArgs = ['billing_pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="col-sm-12">
                                <div class="mb-3">
                                    <label for="billing_address_1" class="form-label">Street address *</label>
                                    <input type="text" class="form-control" id="billing_address_1" name="billing_address_1" class="form-control" required placeholder="House number and street name" value="<?php echo e(old('billing_address_1')); ?>">
                                    <?php $__errorArgs = ['billing_address_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="col-sm-12">
                                <div class="mb-3">
                                    <input type="text" class="form-control" id="billing_address_2" name="billing_address_2" class="form-control" placeholder="Apartment, suite, unit etc. (optional)" value="<?php echo e(old('billing_address_2')); ?>">
                                    <?php $__errorArgs = ['billing_address_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card">
                    <div class="card-body">
                        <h4>Price Details</h4>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <th>Name</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                </thead>
    
                                <tbody>
                                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->quantity); ?></td>
                                        <td>&#x20b9;<?php echo e($item->price); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <table class="table">
                                    <tr>
                                        <th colspan="2">Total Amount: </th>
                                        <th>&#x20b9;<?php echo e(Cart::getTotal()); ?></th>
                                    </tr>
            
                                    <tr>
                                        <th colspan="2">GST</th>
                                        <td>&#x20b9;<?php echo e(Cart::getTotal() * (18 / 100)); ?> <small>(18%)</small></td>
                                    </tr>
            
                                    <tr>
                                        <th colspan="2">Sub Total: </th>
                                        <th>&#x20b9;<?php echo e(Cart::getTotal()  * ((100 + 18) / 100)); ?> 
                                        </th>
                                    </tr>
                                </table>
                            </table>
                        </div>

                        <input type="hidden" name="amount" id="amount" value="<?php echo e(Cart::getTotal()  * ((100 + 18) / 100)); ?>">
                        <input type="hidden" name="bag" id="bag" value="<?php echo e(json_encode($cartItems)); ?>">
    
                        <?php if(auth()->guard()->check()): ?>
                        <button class="btn btn-primary w-100">
                            Proceed to Payment (&#x20b9;<?php echo e(Cart::getTotal()  * ((100 + 18) / 100)); ?>)
                        </button>
                        <?php else: ?>
                        <div class="alert alert-danger" role="alert">
                            Please <a href="<?php echo e(route('login')); ?>">Login</a> or <a href="<?php echo e(route('register')); ?>">Register</a> to Place your order
                        </div>
                        <?php endif; ?>
                    
                    </div>
                </div>
            </div>
    
            <?php else: ?>
    
            <div class="col-sm-4">
                <div class="card">
                    <div class="card-body text-center">
                        <h3>Your Cart is empty !</h3>
                        <a href="/" class="btn btn-primary">Continue Shopping</a>
                    </div>
                </div>
            </div>
    
            <?php endif; ?>
            
    
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cietncert/test-commerce/resources/views/cart/checkout.blade.php ENDPATH**/ ?>