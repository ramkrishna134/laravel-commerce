<?php $__env->startSection('title'); ?> Cart | <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('success')): ?>
    <div class="position-fixed bottom-0 end-0 p-3">
        <div class="toast fade show align-items-center text-white bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
            <div class="toast-body">
                <i class="fa-solid fa-check"></i> <?php echo e($message); ?>

            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="breadcrumb-wrap bg-info py-2 mt-1">
    <div class="container">
        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
              <li class="breadcrumb-item"><a href="/">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Cart</li>
            </ol>
          </nav>
    </div>
</div>

<div class="container mt-4">

    <h1 class="h2 text-center">Your Cart</h1>
    
    <div class="row justify-content-center">

        <?php if(count($cartItems) != 0): ?>

        <div class="col-sm-9">
            
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <th width=50></th>
                                <th>Name</th>
                                <th width=150>Quantity</th>
                                <th>Price</th>
                                <th>Action</th>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr>
                                    <td>
                                        <?php if( empty($item->attributes->image) ): ?>
                                        <img class="img-fluid rounded" src="https://ik.imagekit.io/a39gv6hwd/placeholder-image.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1656864445558" alt="<?php echo e($item->name); ?>">
                                        <?php else: ?>
                                        <img src="<?php echo e($item->attributes->image); ?>" class="img-fluid rounded" alt="<?php echo e($item->name); ?>">
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($item->id); ?>" >

                                            <div class="input-group mb-3">
                                                <input type="number" class="form-control" name="quantity" max="5" aria-describedby="quantity" value="<?php echo e($item->quantity); ?>">
                                                <button type="submit" class="btn btn-info btn-sm" type="button" id="quantity"><i class="fa-solid fa-arrows-rotate"></i> Update</button>
                                            </div>
                                            
                                        </form>

                                        
                                    </td>
                                    <td>&#x20b9;<?php echo e($item->price); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('cart.remove')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                                            <button class="btn btn-danger btn-sm"><i class="fa-solid fa-trash-can"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="row">
                        <div class="col-6">
                            <a href="/" class="btn btn-primary">Continue Shopping</a>
                        </div>
                        <div class="col-6 text-end">
                            <form action="<?php echo e(route('cart.clear')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger"><i class="fa-solid fa-trash-can"></i> Remove All Items</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="card">
                <div class="card-body">
                    <h4>Price Details</h4>
                    <table class="table">
                        <tr>
                            <th>Total Amount: </th>
                            <th>&#x20b9;<?php echo e(Cart::getTotal()); ?></th>
                        </tr>

                        <tr>
                            <th>GST</th>
                            <td> <?php echo e(Cart::getTotal() * (18 / 100)); ?> <small>(18%)</small></td>
                        </tr>

                        <tr>
                            <th>Sub Total: </th>
                            <th>&#x20b9;
                                <?php echo e(Cart::getTotal()  * ((100 + 18) / 100)); ?> 
                            </th>
                        </tr>
                    </table>

                    <a href="/" class="btn btn-primary w-100 btn-lg">Checkout (&#x20b9;<?php echo e(Cart::getTotal()  * ((100 + 18) / 100)); ?>)</a>
                
                </div>
            </div>
        </div>

        <?php else: ?>

        <div class="col-sm-4">
            <div class="card">
                <div class="card-body text-center">
                    <h3>Your Cart is empty !</h3>
                    <a href="/" class="btn btn-primary">Continue Shopping</a>
                </div>
            </div>
        </div>

        <?php endif; ?>
        

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cietncert/test-commerce/resources/views/cart/cart.blade.php ENDPATH**/ ?>