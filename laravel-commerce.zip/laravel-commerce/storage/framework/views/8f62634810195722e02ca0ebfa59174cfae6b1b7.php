<?php $__env->startSection('title'); ?><?php echo e($product->title); ?> | <?php $__env->stopSection(); ?>
<?php $__env->startSection('image'); ?>/storage/<?php echo e($product->image); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e($product->meta_description ?? $product->description); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('keyword'); ?><?php echo e($product->keyword); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="breadcrumb-wrap bg-info py-2 mt-1">
    <div class="container">
        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
              <li class="breadcrumb-item"><a href="/">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->title); ?></li>
            </ol>
          </nav>
    </div>
</div>

<div class="container mt-4">
    <div class="row justify-content-center">

        <div class="col-sm-9">
            <div class="card mb-2">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-4">
                            <?php if(empty($product->image)): ?>
                            <img class="img-fluid" src="https://ik.imagekit.io/a39gv6hwd/placeholder-image.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1656864445558" alt="<?php echo e($product->title); ?>">
                            <?php else: ?>
                            <img class="img-fluid" src="/storage/<?php echo e($product->image); ?>" alt="<?php echo e($product->title); ?>">
                            <?php endif; ?>
                        </div>

                        <div class="col-sm-8">
                            <h5><span class="text-secondary"><strong><?php echo e($product->category->title); ?></strong></span></h5>
                            <h1 class="h4"><strong><?php echo e($product->title); ?></strong></h1>
                            <p class="h4 text-success"><strong>&#x20b9;<?php echo e($product->price); ?></strong></p>
                            

                            <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                                <input type="hidden" value="<?php echo e($product->title); ?>" name="name">
                                <input type="hidden" value="<?php echo e($product->price); ?>" name="price">
                                <input type="hidden" value="<?php echo e($product->slug); ?>" name="slug">
                                <input type="hidden" value="1" name="quantity">
                                <input type="hidden" value="/storage/<?php echo e($product->image); ?>"  name="image">
                                <input type="hidden" value="1" name="quantity">
                                <button class="btn btn-primary btn-lg"><i class="fa-solid fa-bag-shopping"></i> Add To Cart</button>
                            </form>

                            <hr>

                            <h6><strong>Product Details</strong></h6>
                            <p><?php echo e($product->description); ?></p>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cietncert/test-commerce/resources/views/product/single.blade.php ENDPATH**/ ?>