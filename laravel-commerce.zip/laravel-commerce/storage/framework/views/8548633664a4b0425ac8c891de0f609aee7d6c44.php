<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <form action="<?php echo e(route('index')); ?>">

        <div class="row justify-content-center">

            <div class="col-sm-3">
                <div class="card mb-3">
                    <div class="card-body">
                        <h4><strong>Filters</strong></h4>
    
                        <div class="mb-3">
                            <label for="category_id" class="form-label">Category</label>
                            <select name="category_id" id="category_id" class="form-control">
                                <option value="">All Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php if($params['category_id'] == $category->id): ?> selected <?php endif; ?>><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
    
                        <button type="submit" class="btn btn-primary w-100">Apply</button>
                    </div>
                </div>
            </div>
            <div class="col-sm-9">

                <div class="row product-wrap align-items-stretch">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4 mb-3">
                        <div class="card single-item">
                            <div class="card-body p-1 text-center">
                                <div class="image">
                                    <?php if(empty($product->image)): ?>
                                    <img class="img-fluid mb-2" src="https://ik.imagekit.io/a39gv6hwd/placeholder-image.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1656864445558" alt="<?php echo e($product->title); ?>">
                                    <?php else: ?>
                                    <img class="img-fluid mb-2" src="/storage/<?php echo e($product->image); ?>" alt="<?php echo e($product->title); ?>">
                                    <?php endif; ?>
                                </div>
    
                                <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="title"><?php echo e($product->title); ?></a>
                                <div class="price">&#x20b9;<?php echo e($product->price); ?></div>
                            </div>
    
                            <div class="buttons-wrap text-center">
                                <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="btn btn-primary btn-sm me-1"><i class="fa-solid fa-eye"></i> View Details</a>
                            </div>
    
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cietncert/test-commerce/resources/views/welcome.blade.php ENDPATH**/ ?>