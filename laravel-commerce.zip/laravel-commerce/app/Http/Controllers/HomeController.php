<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\Product;
use App\Models\Category;

class HomeController extends Controller
{

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public function home(Request $request)
    {
        $categories = Category::all();

        $params = $this->validate($request, [
            'category_id' => 'nullable',
        ]);

        $query = Product::query()->orderByDesc('id')->where('status' ,1);

        $params['category_id'] = trim( $params['category_id'] ?? '' );

        if( !empty( $params['category_id'] ) ){
            $query->where('category_id', $params['category_id']);
        }

        $products = $query->paginate();
        // dd($products);

        return view('welcome')->with([
            'products' => $products, 
            'categories' => $categories, 
            'params' => $params,
        ]);
    }

    public function dashboard()
    {
        return view('admin.dashboard');
    }

    public function search(Request $request) {

        if($request->get('query')){
            $query = $request->get('query');

            $products[] = \DB::table('products')->where("keyword", "LIKE", '%' . $query . '%')->get();

            $datas = $products;

            return response()->json($datas);
        }
        
    }
}
