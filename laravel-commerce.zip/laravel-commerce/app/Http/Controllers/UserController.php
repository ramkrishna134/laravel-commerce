<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{

    public function index(){
        $users = User::all();
        return view('admin.user.index', compact('users'));
    }

    // Edit User view ===========
    public function edit(User $user){
        $roles = Role::all();
        return view('admin.user.edit', compact('user', 'roles'));
    }

    // Assign User role ===========
    public function assignRole(Request $request, User $user){
        if($user->hasRole($request->role)){
            return back()->with('status', 'Role exist');
        }

        $user->assignRole($request->role);
        return back()->with('status', 'Role Assigned');
    }


    // Revoke User role ===========
    public function revokeRole(User $user, Role $role){
        if($user->hasRole($role)){
            $user->removeRole($role);
            return back()->with('status',"Role Revoked");
        }
    }


    // Update User ===========
    public function update(Request $request, User $user){

        $data = $this->validate( $request, [
            'name' => 'required',
        ]);

        // dd($user);

        $user->fill( $data );
        // if( $request->password ){
        //     $user->password = Hash::make( $request->password );
        // }

        $user->saveOrFail();

        return back()->with('status'," User Details has been Updated successfully");

    }


    // Delete User ===========
    public function destroy(User $user){
        $user->delete();
        return back()->with('status', 'User deleted successfully');
    }
}
