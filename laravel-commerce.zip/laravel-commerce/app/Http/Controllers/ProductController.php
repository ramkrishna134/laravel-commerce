<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $products = Product::withTrashed()->get();
        return view('admin.product.index', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $categories = Category::query()->where('status', 1)->get();
        return view('admin.product.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreProductRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreProductRequest $request)
    {
        $user = auth()->user();
        $validated = $request->validated();
        $data = $validated;
        $product = new Product($data);
        if( empty( $product->slug ) ){
            $product->slug = Str::slug( $data['title'] );
        }

        $path_dis_image = '';
        if($request->hasFile('image')){
            $fileValue     = $request->image;
            $getFileExt   = $fileValue->getClientOriginalExtension();
            $custom_file_name = rand(0,50).'-prod'.'.'.$getFileExt;
            $path_dis_image = $request->file('image')->storeAs('product', $custom_file_name);
            $product->image = $path_dis_image;
        }
        $product->user_id = $user->id;
        $product->save();
        return redirect(route('product.index'))->with('status', 'New Product added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product, $slug)
    {
        $product = Product::where('slug', $slug)->where('status', 1)->first();
        return view('product.single', compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        $categories = Category::query()->where('status', 1)->get();
        return view('admin.product.edit', compact('product', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateProductRequest  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateProductRequest $request, Product $product)
    {
        //
        $user = auth()->user();
        $validated = $request->validated();
        $data = $validated;
        $product->fill($data);
        if( empty( $product->slug ) ){
            $product->slug = Str::slug( $data['title'] );
        }

        $path_dis_image = '';
        if($request->hasFile('image')){
            $fileValue     = $request->image;
            $getFileExt   = $fileValue->getClientOriginalExtension();
            $custom_file_name = rand(0,50).'-prod'.'.'.$getFileExt;
            $path_dis_image = $request->file('image')->storeAs('product', $custom_file_name);
            $product->image = $path_dis_image;
        }
        $product->user_id = $user->id;
        $product->save();
        return back()->with('status', 'Product Updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        $product->delete();
        return back()->with('status', 'Product moved to Trash');
    }


    public function restore($id)
    {
        //
        Product::onlyTrashed()->find($id)->restore();
        return back()->with('status', 'Product restore successfully');
    }


    public function delete($id)
    {
        //
        Product::onlyTrashed()->find($id)->forceDelete();
        return back()->with('status', 'Product delete successfully');
    }
}
