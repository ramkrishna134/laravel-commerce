<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Validator;

class PermissionController extends Controller
{

    public function index(){
        $permissions = Permission::all();
        return view('admin.permission.index', compact('permissions'));
    }


    public function create(){
        return view('admin.permission.create');
    }


    public function show(Permission $permission){
        
    }


    public function edit(Permission $permission){
        return view('admin.permission.edit', compact('permission'));
    }


    public function store(Request $request){
        $rules = [
            'name' =>'required|max:255',
        ];
        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
			return back()
			->withInput()
			->withErrors($validator);
		}else{
            $data = $request->input();
			try{
                
                Permission::create($data);
                return redirect(route('permission.index'))->with('status'," New Permision added successfully");

			}
			catch(Exception $e){
				return back()->with('failed',"Operation failed");
			}
		}
    }


    public function update(Request $request, Permission $permission){
        $rules = [
            'name' =>'required|max:255',
        ];
        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
			return back()
			->withInput()
			->withErrors($validator);
		}else{
            $data = $request->input();
			try{
                
                $permission->fill($data);
                $permission->save();
                return back()->with('status',"Permision updated successfully");

			}
			catch(Exception $e){
				return back()->with('failed',"Operation failed");
			}
		}
    }

    public function destroy(Permission $permission){
        $permission->delete();
        return back()->with('status', 'Permission deleted successfully');
    }

    
}
