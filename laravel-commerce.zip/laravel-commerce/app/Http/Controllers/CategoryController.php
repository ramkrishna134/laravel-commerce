<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCategoryRequest;
use App\Http\Requests\UpdateCategoryRequest;
use App\Models\Category;
use App\Models\Product;
use App\Policies\CategoryPolicy;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $categories = Category::withTrashed()->get();
        return view('admin.category.index', compact('categories'));
    }

    public function list()
    {
        //
        $categories = Category::all();
        return view('category', compact('categories'));
    }

    public function category(Product $product, $slug)
    {
        //
        $category = Category::query()->where('slug', $slug)->first();
        $products = Product::query()->where('category_id', $category->id)->get();
        return view('product.product-cat', compact('category', 'products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('admin.category.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreCategoryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCategoryRequest $request)
    {
        $user = auth()->user();
        $validated = $request->validated();
        $data = $validated;
        $category = new Category($data);
        if( empty( $category->slug ) ){
            $category->slug = Str::slug( $data['title'] );
        }

        $path_dis_image = '';
        if($request->hasFile('icon')){
            $fileValue     = $request->icon;
            $getFileExt   = $fileValue->getClientOriginalExtension();
            $custom_file_name = rand(0,50).'-cat'.'.'.$getFileExt;
            $path_dis_image = $request->file('icon')->storeAs('category', $custom_file_name);
            $category->icon = $path_dis_image;
        }
        $category->user_id = $user->id;
        $category->save();
        return redirect(route('category.index'))->with('status', 'New Category added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function show(Category $category)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function edit(Category $category)
    {
        //
        return view('admin.category.edit', compact('category'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateCategoryRequest  $request
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateCategoryRequest $request, Category $category)
    {
        //

        $user = auth()->user();
        $validated = $request->validated();
        $data = $validated;
        $category->fill($data);
        if( empty( $category->slug ) ){
            $category->slug = Str::slug( $data['title'] );
        }

        $path_dis_image = '';
        if($request->hasFile('icon')){
            $fileValue     = $request->icon;
            $getFileExt   = $fileValue->getClientOriginalExtension();
            $custom_file_name = rand(0,50).'-cat'.'.'.$getFileExt;
            $path_dis_image = $request->file('icon')->storeAs('category', $custom_file_name);
            $category->icon = $path_dis_image;
        }
        $category->user_id = $user->id;
        $category->save();
        return back()->with('status', 'Category Updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function destroy(Category $category)
    {
        //
        $category->delete();
        return back()->with('status', 'Category moved to Trash');
    }


    public function restore($id)
    {
        //
        Category::onlyTrashed()->find($id)->restore();
        return back()->with('status', 'Category restore successfully');
    }


    public function delete($id)
    {
        //
        Category::onlyTrashed()->find($id)->forceDelete();
        return back()->with('status', 'Category delete successfully');
    }
}
