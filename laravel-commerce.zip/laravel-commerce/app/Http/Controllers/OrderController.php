<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Http\Requests\StoreOrderRequest;
use App\Http\Requests\UpdateOrderRequest;
use Razorpay\Api\Api;
use Stripe;
use Illuminate\Http\Request;
use Ramsey\Uuid\Uuid;
use Session;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $user = auth()->user();
        $orders = Order::query()->orderBy('created_at', 'desc')->where('user_id', $user->id)->get();
        return view('order.index', compact('orders'));
    }



    /**
     * Display a listing of the resource in admin.
     *
     * @return \Illuminate\Http\Response
     */
    public function admin()
    {
        //
        $orders = Order::query()->orderBy('created_at', 'desc')->paginate(10);
        return view('admin.order.index', compact('orders'));
    }

    public function adminSingle(Order $order)
    {
        //
        return view('admin.order.single', compact('order'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreOrderRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreOrderRequest $request)
    {

        $user = auth()->user();
        $validated = $request->validated();
        $data = $validated;
        $order = new Order($data);
        $order->uuid = Uuid::uuid4()->toString();
        $order->user_id = $user->id;
        $order->bag = $request['bag'];
        $order->amount = $request['amount'];
        $order->payment_method = 'razorpay';
        $order->save();
        return redirect(route('razorpay.get'))->with([
            'amount' => $request['amount'],
            'name' => $request['billing_name'],
            'email' => $request['billing_email'],
            'phone' => $request['billing_phone']
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function show(Order $order)
    {
        //
        return view('order.single', compact('order'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateOrderRequest  $request
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateOrderRequest $request, Order $order)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
        //
    }

    public function handleGet()
    {
        return view('cart.payment');
    }

    public function handlePost(Request $request)
    {
        $this->validate($request, [
            'card_no' => 'required',
            'expiry_month' => 'required',
            'expiry_year' => 'required',
            'cvv' => 'required',
        ]);
 
        $stripe = Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
        try {
            $response = \Stripe\Token::create(array(
                "card" => array(
                    "number"    => $request->input('card_no'),
                    "exp_month" => $request->input('expiry_month'),
                    "exp_year"  => $request->input('expiry_year'),
                    "cvc"       => $request->input('cvv')
                )));
            if (!isset($response['id'])) {
                return redirect()->route('addmoney.paymentstripe');
            }
            $charge = \Stripe\Charge::create([
                'card' => $response['id'],
                'currency' => 'USD',
                'amount' =>  100 * 100,
                'description' => 'wallet',
            ]);
 
            if($charge['status'] == 'succeeded') {
                return back()->with('success', 'Payment Success!');
 
            } else {
                return back()->with('error', 'something went to wrong.');
            }
 
        }
        catch (Exception $e) {
            return $e->getMessage();
        }
    }


    // Razor payment page get =====================
    public function razorGet()
    {        
        return view('cart.paymentrzr');
    }

    // Razor payment store ==================
    public function razorPost(Request $request)
    {
        $input = $request->all();

        $api = new Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));
        $payment = $api->payment->fetch($input['razorpay_payment_id']);
        
  
        if(count($input)  && !empty($input['razorpay_payment_id'])) {
            try {
                $response = $api->payment->fetch($input['razorpay_payment_id'])->capture(array('amount'=>$payment['amount'])); 
  
            } catch (Exception $e) {
                return  $e->getMessage();
                Session::put('error',$e->getMessage());
                return redirect()->back();
            }
        }
        \Cart::clear();
        $user = auth()->user();
        $order = Order::query()->where('user_id', $user->id)->latest('created_at')->first();
        $order->status = 'complete';
        $order->save();
        return redirect(route('order.thankyou'));
    }

    public function thankyou(){
        return view('cart.thankyou');
    }
}
