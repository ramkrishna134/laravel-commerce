<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Validator;

class RoleController extends Controller
{

    public function index(){
        $roles = Role::all();
        return view('admin.role.index', compact('roles'));
    }

    public function create(){
        return view('admin.role.create');
    }

    public function store(Request $request){
        $rules = [
            'name' =>'required|max:255',

        ];
        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
			return back()
			->withInput()
			->withErrors($validator);
		}else{
            $data = $request->input();
			try{
                
                Role::create($data);
                // return redirect(route('student.dashboard'))->with('status',"Your Profile has Updated successfully");
                return redirect(route('role.index'))->with('status'," New Rule added successfully");

			}
			catch(Exception $e){
				return back()->with('failed',"Operation failed");
			}
		}
    }

    public function edit(Role $role){
        $permissions = Permission::all();
        return view('admin.role.edit', compact('role', 'permissions'));
    }

    public function update(Request $request, Role $role){
        $rules = [
            'name' =>'required|max:255',
        ];
        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
			return back()
			->withInput()
			->withErrors($validator);
		}else{
            $data = $request->input();
			try{
                $role->fill($data);
                $role->save();
                return back()->with('status',"Rule updated successfully");

			}
			catch(Exception $e){
				return back()->with('failed',"Operation failed");
			}
		}
    }

    public function givePermission(Request $request, Role $role){
        if($role->hasPermissionTo($request->permission)){
            return back()->with('status',"Permission already Exist");
        }

        $role->givePermissionTo($request->permission);
        return back()->with('status',"Permission Added");
    }

    public function revokePermission(Role $role, Permission $permission){
        if($role->hasPermissionTo($permission)){
            $role->revokePermissionTo($permission);
            return back()->with('status',"Permission Revoked");
        }
    }

    public function destroy(Role $role){
        $role->delete();
        return back()->with('status',"Role Removed");
    }
}
