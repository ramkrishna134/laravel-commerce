<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreOrderRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'billing_name' => 'required',
            'billing_email' => 'required|email',
            'billing_company' => '',
            'billing_phone' => 'required|digits:10',
            'billing_country' => 'required',
            'billing_address_1' => '',
            'billing_address_2' => '',
            'billing_city' => '',
            'billing_state' => '',
            'billing_pincode' => 'required',
        ];
    }
}
