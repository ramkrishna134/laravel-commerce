<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Product;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $products = [
            [
                'title' => 'Men Maroon & Navy Blue Checked Pure Cotton Casual Sustainable Shirt',
                'category_id' => 1,
                'slug' => 'men-maroon-navy-blue-checked-pure-cotton-casual-sustainable-shirt',
                'image' => '',
                'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries',
                'price' => '849',
                'meta_description' => '',
                'keyword' => 'Men Maroon & Navy Blue Checked Pure Cotton Casual Sustainable Shirt, Roadstar',
                'status' => 1,
                'user_id' => 1
            ],

            [
                'title' => 'Puma Mens Regular T-Shirt',
                'category_id' => 1,
                'slug' => 'puma-mens-regular-t-shirt',
                'image' => '',
                'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries',
                'price' => '499',
                'meta_description' => '',
                'keyword' => 'Puma Mens Regular T-Shirt, Puma',
                'status' => 1,
                'user_id' => 1
            ],

            [
                'title' => 'Wrangler Vegas Blue Solid Skinny Fit Jeans',
                'category_id' => 2,
                'slug' => 'wrangler-vegas-blue-solid-skinny-fit-jeans',
                'image' => '',
                'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries',
                'price' => '2399',
                'meta_description' => '',
                'keyword' => 'Wrangler Vegas Blue Solid Skinny Fit Jeans, Wrangler',
                'status' => 1,
                'user_id' => 1
            ],

            [
                'title' => 'Demo Jeans 2',
                'category_id' => 2,
                'slug' => 'wrangler-vegas-blue-solid-skinny-fit-jeans-2',
                'image' => '',
                'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries',
                'price' => '2399',
                'meta_description' => '',
                'keyword' => 'Wrangler Vegas Blue Solid Skinny Fit Jeans, Wrangler',
                'status' => 1,
                'user_id' => 1
            ],

            [
                'title' => 'Puma Mens Regular T-Shirt 2',
                'category_id' => 2,
                'slug' => 'puma-mens-regular-t-shirt-2',
                'image' => '',
                'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries',
                'price' => '499',
                'meta_description' => '',
                'keyword' => 'Puma Mens Regular T-Shirt, Puma',
                'status' => 1,
                'user_id' => 2
            ],

            [
                'title' => 'Puma Mens Regular Shirt',
                'category_id' => 1,
                'slug' => 'puma-mens-regular-shirt',
                'image' => '',
                'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries',
                'price' => '499',
                'meta_description' => '',
                'keyword' => 'Puma Mens Regular T-Shirt, Puma',
                'status' => 1,
                'user_id' => 2
            ],

        ];

        Product::insert($products);
    }
}
