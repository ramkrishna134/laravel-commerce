@extends('layouts.app')

@section('title') Categories | @endsection 
@section('content')

<div class="breadcrumb-wrap bg-info py-2 mt-1">
    <div class="container">
        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
              <li class="breadcrumb-item"><a href="/">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Categories</li>
            </ol>
          </nav>
    </div>
</div>

<div class="container mt-4">
    <div class="row justify-content-center">

        @foreach ($categories as $category)
            <div class="col-sm-3">
                <a href="{{ route('category.product', $category->slug) }}" class="card mb-1">
                    <div class="row align-items-center">
                        <div class="col-3">
                            @if(empty($category->image))
                            <img class="img-fluid" src="https://ik.imagekit.io/a39gv6hwd/placeholder-image.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1656864445558" alt="{{ $category->title }}">
                            @else
                            <img class="img-fluid" width="50px" src="/storage/{{ $category->icon }}" alt="{{ $category->title }}">
                            @endif
                        </div>
                        <div class="col-9">
                            <h6 class="mb-0"><strong>{{ $category->title }}</strong></h6>
                        </div>
                    </div>
                </a>
            </div>
        @endforeach

    </div>
</div>
@endsection