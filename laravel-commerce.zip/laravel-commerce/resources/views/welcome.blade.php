@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <form action="{{ route('index') }}">

        <div class="row justify-content-center">

            <div class="col-sm-3">
                <div class="card mb-3">
                    <div class="card-body">
                        <h4><strong>Filters</strong></h4>
    
                        <div class="mb-3">
                            <label for="category_id" class="form-label">Category</label>
                            <select name="category_id" id="category_id" class="form-control">
                                <option value="">All Category</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}" @if($params['category_id'] == $category->id) selected @endif>{{ $category->title }}</option>
                                @endforeach
                            </select>
                        </div>
    
                        <button type="submit" class="btn btn-primary w-100">Apply</button>
                    </div>
                </div>
            </div>
            <div class="col-sm-9">

                <div class="row product-wrap align-items-stretch">
                    @foreach($products as $product)
                    <div class="col-sm-4 mb-3">
                        <div class="card single-item">
                            <div class="card-body p-1 text-center">
                                <div class="image">
                                    @if(empty($product->image))
                                    <img class="img-fluid mb-2" src="https://ik.imagekit.io/a39gv6hwd/placeholder-image.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1656864445558" alt="{{ $product->title }}">
                                    @else
                                    <img class="img-fluid mb-2" src="/storage/{{ $product->image }}" alt="{{ $product->title }}">
                                    @endif
                                </div>
    
                                <a href="{{ route('product.show', $product->slug) }}" class="title">{{ $product->title }}</a>
                                <div class="price">&#x20b9;{{ $product->price }}</div>
                            </div>
    
                            <div class="buttons-wrap text-center">
                                <a href="{{ route('product.show', $product->slug) }}" class="btn btn-primary btn-sm me-1"><i class="fa-solid fa-eye"></i> View Details</a>
                            </div>
    
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

    </form>
</div>
@endsection