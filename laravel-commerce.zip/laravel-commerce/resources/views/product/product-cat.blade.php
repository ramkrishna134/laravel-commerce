@extends('layouts.app')

@section('title'){{ $category->title }} | @endsection
@section('image')/storage/{{ $category->icon }}@endsection
@section('description'){{ $category->description }} @endsection

@section('content')

<div class="breadcrumb-wrap bg-info py-2 mt-1">
    <div class="container">
        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
              <li class="breadcrumb-item"><a href="/">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">{{ $category->title }}</li>
            </ol>
          </nav>
    </div>
</div>


<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-sm-9">
            <h1 class="h3 text-center">{{ $category->title }}</h1>
            <div class="row product-wrap align-items-stretch justify-content-center">
                @foreach($products as $product)
                <div class="col-sm-4 mb-3">
                    <div class="card single-item">
                        <div class="card-body p-1 text-center">
                            <div class="image">
                                @if(empty($product->image))
                                <img class="img-fluid mb-2" src="https://ik.imagekit.io/a39gv6hwd/placeholder-image.webp?ik-sdk-version=javascript-1.4.3&updatedAt=1656864445558" alt="{{ $product->title }}">
                                @else
                                <img class="img-fluid mb-2" src="/storage/{{ $product->image }}" alt="{{ $product->title }}">
                                @endif
                            </div>

                            <a href="{{ route('product.show', $product->slug) }}" class="title">{{ $product->title }}</a>
                            <div class="price">&#x20b9;{{ $product->price }}</div>
                        </div>

                        <div class="buttons-wrap text-center">
                            <a href="{{ route('product.show', $product->slug) }}" class="btn btn-primary btn-sm me-1"><i class="fa-solid fa-eye"></i> View Details</a>
                            <hr>
                            <form action="{{ route('cart.store') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                @method('post')
                                <input type="hidden" value="{{ $product->id }}" name="id">
                                <input type="hidden" value="{{ $product->title }}" name="name">
                                <input type="hidden" value="{{ $product->price }}" name="price">
                                <input type="hidden" value="{{ $product->slug }}" name="slug">
                                <input type="hidden" value="1" name="quantity">
                                <input type="hidden" value="/storage/{{ $product->image }}"  name="image">
                                <input type="hidden" value="1" name="quantity">
                                <button class="btn btn-primary btn-sm"><i class="fa-solid fa-bag-shopping"></i> Add To Cart</button>
                            </form>
                        </div>

                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
@endsection