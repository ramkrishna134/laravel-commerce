<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class AppTest extends TestCase
{
    /**
     * A basic unit test example.
     *
     * @return void
     */
    public function test_example()
    {
        $this->assertTrue(true);
    }
}
